<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Activities;
use App\Models\Submissions;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'role:user']);
    }

    public function index()
    {
        //parent()->subscribed(auth()->user()->plan_id);
        $weeks = auth()->user()->weeks()->get();

        return view('panel.user.programme', [
            'weeks' => $weeks
        ]);
    }

    // POST
    public function storeSubmission(Activities $activitie)
    {
        if (request()->hasFile('fileToUpload')) {
            $file = request()->file('fileToUpload');
            $file_name = Str::uuid() . "." . $file->getClientOriginalExtension();
            $file->storeAs('files', $file_name, 'public');

            Submissions::create([
                'activite_id' => $activitie->id,
                'description' => request()->description,
                'file'        => 'upload/files/' . $file_name
            ]);
        }
        return redirect()->back()->withMessage('Saved Submission');
    }
}
