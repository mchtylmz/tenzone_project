<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\Activities;
use App\Models\User;
use App\Models\Weeks;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'role:teacher']);
    }

    public function index()
    {
        return view('panel.teacher.welcome', [
            'childs' =>  User::role('user')->get()
        ]);
    }

    public function child_programme(User $child)
    {
        $weeks = $child->weeks()->get();

        return view('panel.teacher.programme', [
            'child' => $child,
            'weeks' => $weeks
        ]);
    }

    public function reports()
    {
        return view('panel.teacher.welcome');
    }

    public function connect()
    {
        return view('panel.teacher.welcome');
    }


    // POST
    protected function store_week()
    {
        Validator::make(request()->all(), [
            'user_id'     => ['required', 'integer'],
            'title'       => ['required', 'string', 'max:255'],
            'start_date'  => ['required', 'string', 'max:10'],
            'end_date'    => ['required', 'string', 'max:10']
        ])->validate();

        Weeks::create([
            'user_id'    => request()->user_id,
            'title'      => request()->title,
            'start_date' => date('Y-m-d', strtotime(request()->start_date)),
            'end_date'   => date('Y-m-d', strtotime(request()->end_date)),
        ]);

        return redirect()->back()->withMessage('Successfully Added');
    }

    protected function store_activity(Weeks $week)
    {
        Validator::make(request()->all(), [
            'title'  => ['required', 'string', 'max:255'],
            'type'   => ['required', 'string', 'max:255']
        ])->validate();

        if (request()->hasFile('watch')) {
            $watch = request()->file('watch');
            $watch_name = Str::uuid() . "." . $watch->getClientOriginalExtension();
            $watch->storeAs('files', $watch_name, 'public');
        }
        if (request()->hasFile('document')) {
            $document = request()->file('document');
            $doc_name = Str::uuid() . "." . $document->getClientOriginalExtension();
            $document->storeAs('files', $doc_name, 'public');
        }

        Activities::create([
            'week_id'    => $week->id,
            'teacher_id' => auth()->user()->id,
            'title'      => request()->title,
            'type'       => request()->type,
            'watch'      => isset($watch_name) ? 'upload/files/'.$watch_name : null,
            'download'   => isset($doc_name)   ? 'upload/files/'.$doc_name : null
        ]);

        return redirect()->back()->withMessage('Successfully Added');
    }


    // DELETE
    protected function delete_activite(Activities $activite)
    {
        Activities::destroy($activite->id);

        return redirect()->back()->withMessage('Successfully Delete');
    }
}
