<x-site-layout>
    <x-slot name="style">home.css</x-slot>
    <x-slot name="title">{{ __('404') }}</x-slot>

    <section class="pb-5 mb-5 pt-0">
        <div class="container text-center pt-5">
            <h2>{{ __('404 Not Found') }}</h2>
        </div>
    </section>
</x-site-layout>
