<script>
    const lang = {
        unknown_error: '{{ __('message.unknown_error') }}'
    }
</script>
