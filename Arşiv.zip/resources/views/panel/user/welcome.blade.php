<x-panel-layout>
    <x-slot name="title">{{ __('User Home') }}</x-slot>

    <div class="tm-page-head">
        <h1 class="title">Programme</h1>
        <p class="text mb-0">You can see your scheduled programs here.</p>
    </div>
</x-panel-layout>
