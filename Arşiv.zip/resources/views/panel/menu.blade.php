@hasanyrole('user')
    @props(['prefix' => 'user'])
@endhasanyrole

@hasanyrole('parent')
    @props(['prefix' => 'parent'])
@endhasanyrole

@hasanyrole('teacher')
    @props(['prefix' => 'teacher'])
@endhasanyrole

@hasanyrole('theraphy')
    @props(['prefix' => 'theraphy'])
@endhasanyrole

@hasanyrole('superadmin|admin')

<li>
    <a href="programme.html" class="active">
        <div class="icon"><i class="ri-file-list-2-line"></i></div>
        ADMİN
    </a>
</li>

@else

<li>
    <a href="{{ route($prefix . '.index') }}" class="{{
        in_array(request()->route()->getName(), [$prefix . '.index', $prefix . '.child_programme']) ? 'active':''
    }}">
        <div class="icon"><i class="ri-file-list-2-line"></i></div>
        Programme
    </a>
</li>
<li>
    <a href="{{ route($prefix . '.reports') }}" class="{{ request()->route()->getName() == $prefix . '.reports' ? 'active':'' }}">
        <div class="icon"><i class="ri-funds-box-line"></i></div>
        Reports
    </a>
</li>
<li>
    <a href="{{ route($prefix . '.connect') }}" class="{{ request()->route()->getName() == $prefix . '.connect' ? 'active':'' }}">
        <div class="icon"><i class="ri-chat-smile-2-line"></i></div>
        Connect
    </a>
</li>

@endhasanyrole



