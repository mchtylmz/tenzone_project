<x-panel-layout>
    <x-slot name="title">{{ __('Admin Home') }}</x-slot>


</x-panel-layout>
