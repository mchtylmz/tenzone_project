
$('#tz-slider-how').owlCarousel({
    loop: false,
    margin: 30,
    nav: false,
    dots: false,
    responsive: {
        1200: {
            items: 3
        },
        992: {
            items: 3
        },
        768: {
            items: 2
        },
        0: {
            items: 1
        }
    }
});

$('#tz-slider-how-2').owlCarousel({
    loop: false,
    margin: 60,
    nav: false,
    dots: false,
    responsive: {
        1200: {
            items: 3
        },
        992: {
            items: 3
        },
        768: {
            items: 2
        },
        0: {
            items: 1
        }
    }
});

$('#tz-slider-membership').owlCarousel({
    loop: false,
    margin: 30,
    nav: false,
    dots: false,
    responsive: {
        1200: {
            items: 3
        },
        768: {
            items: 2
        },
        0: {
            items: 1
        }
    }
});

$('#tz-slider-membership2').owlCarousel({
    loop: false,
    margin: 30,
    nav: false,
    dots: false,
    responsive: {
        1200: {
            items: 3
        },
        768: {
            items: 2
        },
        0: {
            items: 1
        }
    }
});

$('#tz-slider-comments').owlCarousel({
    loop: false,
    margin: 30,
    nav: false,
    dots: false,
    responsive: {
        1200: {
            items: 2
        },
        768: {
            items: 2
        },
        0: {
            items: 1
        }
    }
});

$('#tz-slider-what-mobile').owlCarousel({
    loop: false,
    margin: 20,
    nav: false,
    dots: false,
    items: 1
});
