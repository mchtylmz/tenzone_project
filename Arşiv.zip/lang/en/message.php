<?php

return [
    'unknown_error' => 'An error occurred, try again later!'
];
