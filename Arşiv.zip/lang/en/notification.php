<?php

return [
    'welcome' => [
        'subject' => 'Welcome',
        'welcome_text' => 'Thanks for registering.',
        'profile_url_text' => 'My Account',
        'send_register_info_mail' => 'A welcome mail has been sent after registration to the site.'
    ]
];
