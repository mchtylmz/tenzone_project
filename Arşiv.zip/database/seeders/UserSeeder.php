<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'admin',
            'surname' => 'suradmin',
            'dob' => date('Y-m-d', strtotime('-20 years')),
            'gender' => 'male',
            'email' => 'admin@admin.com',
            'password' => Hash::make('12345678')
        ]);
        $user->syncRoles('admin');

        $user = User::create([
            'name' => 'teacher',
            'surname' => 'teacher',
            'dob' => date('Y-m-d', strtotime('-24 years')),
            'gender' => 'male',
            'email' => 'teacher@teacher.com',
            'password' => Hash::make('12345678')
        ]);
        $user->syncRoles('teacher');

        $parent = User::create([
            'name' => 'parent',
            'surname' => 'parent',
            'dob' => date('Y-m-d', strtotime('-30 years')),
            'gender' => 'male',
            'email' => 'parent@parent.com',
            'password' => Hash::make('12345678')
        ]);
        $parent->syncRoles('parent');

        $user = User::create([
            'name' => 'child',
            'surname' => 'child',
            'parent_id' => $parent->id,
            'dob' => date('Y-m-d', strtotime('-18 years')),
            'gender' => 'male',
            'email' => 'child@child.com',
            'password' => Hash::make('12345678')
        ]);
        $user->syncRoles('user');
    }
}
