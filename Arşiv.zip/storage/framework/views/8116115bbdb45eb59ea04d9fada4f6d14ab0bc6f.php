<?php if (isset($component)) { $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PanelLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\PanelLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Teacher Home')); ?> <?php $__env->endSlot(); ?>

    <div class="tm-page-head">
        <h1 class="title">Programme</h1>
        <p class="text mb-0">You can see your scheduled programs here.</p>
    </div>

    <div class="row">

        <?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-xl-4">
                <div class="tm-teacher-item tm-card">
                    <div class="img">
                        <img src="<?php echo e(asset('images/profile2.png')); ?>" alt="profile">
                        <div class="circle">
                            <img src="<?php echo e(asset('images/profile.png')); ?>" alt="profile">
                        </div>
                    </div>
                    <h5 class="title"><?php echo e($child->fullname); ?></h5>
                    <a href="<?php echo e(route('teacher.child_programme', $child->id)); ?>" class="btn btn-block btn-light">
                        <?php echo e(__('Child Programme')); ?>

                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937)): ?>
<?php $component = $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937; ?>
<?php unset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/panel/teacher/welcome.blade.php ENDPATH**/ ?>