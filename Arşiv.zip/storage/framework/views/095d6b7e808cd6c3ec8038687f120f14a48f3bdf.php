<?php if (isset($component)) { $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SiteLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SiteLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> default.css <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Confirm Book')); ?> <?php $__env->endSlot(); ?>

    <section class="tz-page">
        <div class="container containerarea">

            <div class="head-title text-center">
                <h1>Confirm Book</h1>
                <img src="<?php echo e(asset('images/line.svg')); ?>" alt="line" class="line">
            </div>

            <div class="tz-time-box mb-4">
                <div class="left">
                        <span class="text">
                            <img src="<?php echo e(asset('images/icons/calendar.svg')); ?>" alt="calendar">
                            <?php echo e($bookdate); ?>

                        </span>
                </div>
                <div class="mid">
                        <span class="text">
                            <img src="<?php echo e(asset('images/icons/clock.svg')); ?>" alt="clock">
                            <?php echo e($booktime); ?>

                        </span>
                </div>
            </div>

            <form action="<?php echo e(route('book.save')); ?>" method="post" class="form-question">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="fullname">First Name and Last Name</label>
                    <input type="text" name="fullname" class="form-control" placeholder="Activity Sheets" required>
                </div>

                <div class="mb-3">
                    <label for="email">Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="Activity Sheets" required>
                </div>

                <div class="mb-3">
                    <label for="phone">Phone Number</label>
                    <input type="text" name="phone" class="form-control" placeholder="Activity Sheets" required>
                </div>

                <input type="hidden" name="time" value="<?php echo e($time); ?>">
                <button type="submit" class="btn btn-primary btn-block btn-icon-hover">
                    Book a session for free <i class="fa fa-arrow-right"></i>
                </button>
            </form>

        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311)): ?>
<?php $component = $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311; ?>
<?php unset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/site/confirm_time.blade.php ENDPATH**/ ?>