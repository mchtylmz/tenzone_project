<?php if($style == 'transparent'): ?>
    <nav class="navbar navbar-expand-lg tz-navbar navbar-transparent" style="background-color: transparent; padding: 23px 0 !important;">
<?php else: ?>
    <nav class="navbar navbar-expand-lg tz-navbar">
<?php endif; ?>
    <div class="container">
        <a href="/" class="navbar-brand"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo"></a>
        <button class="navbar-toggler" type="button" onclick="menuOpen()">
            <i class="fa fa-bars" id="mm-openbtn"></i>
            <i class="fa fa-times" style="display: none;" id="mm-closebtn"></i>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="tenzoneNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <div class="nav_link_has_dropdown">
                        <a class="nav-link" href="javascript:;"><?php echo e(__('Services')); ?></a>
                        <ul class="dropdown_nav_link">
                            <li><a href="<?php echo e(route('service.detail', 'educational')); ?>"><?php echo e(__('Educational Programs')); ?></a></li>
                            <li><a href="<?php echo e(route('service.detail', 'theraphy')); ?>"><?php echo e(__('Theraphy Services')); ?></a></li>
                            <li><a href="<?php echo e(route('service.detail', 'ten')); ?>"><?php echo e(__('Ten Shop')); ?></a></li>
                        </ul>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('store')); ?>"><?php echo e(__('Store')); ?></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('about')); ?>"><?php echo e(__('About')); ?></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('help')); ?>"><?php echo e(__('Help')); ?></a>
                </li>
            </ul>
        </div>

        <div class="collapse navbar-collapse justify-content-end" id="tenzoneNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link btn btn-light btn-cart" href="<?php echo e(route('cart')); ?>">
                        <img src="<?php echo e(asset('images/icons/shop.svg')); ?>" alt="icon">
                    </a>
                </li>
                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item">
                        <a class="nav-link btn btn-primary" href="<?php echo e(route('my.account')); ?>"><?php echo e(__('My Account')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-light btn-cart" href="<?php echo e(route('my.logout')); ?>">
                            <img src="<?php echo e(asset('images/logout.svg')); ?>" alt="icon">
                        </a>
                    </li>

                <?php else: ?>
                    <li class="nav-item"><a class="nav-link btn btn-outline-primary" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-primary" href="<?php echo e(route('plans')); ?>"><?php echo e(__('Sign Up')); ?></a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<div class="tz-mobile-menu" id="mobile-menu" style="display:none;">
    <ul class="list-unstyled mb-4">
        <li>
            <div class="mobil_dropdown_has_nav_link">
                <a href="#"><?php echo e(__('Services')); ?></a>
                <ul class="mobile_dropdown_nav_link">
                    <li><a href="<?php echo e(route('service.detail', 'educational')); ?>"><?php echo e(__('Educational Programs')); ?></a></li>
                    <li><a href="<?php echo e(route('service.detail', 'theraphy')); ?>"><?php echo e(__('Theraphy Services')); ?></a></li>
                    <li><a href="<?php echo e(route('service.detail', 'ten')); ?>"><?php echo e(__('Ten Shop')); ?></a></li>
                </ul>
            </div>
        </li>
        <li>
            <a href="<?php echo e(route('store')); ?>"><?php echo e(__('Store')); ?></a>
        </li>
        <li>
            <a href="<?php echo e(route('about')); ?>"><?php echo e(__('About')); ?></a>
        </li>
        <li>
            <a href="<?php echo e(route('help')); ?>"><?php echo e(__('Help')); ?></a>
        </li>
    </ul>
    <div class="flex-between">
        <a href="<?php echo e(route('cart')); ?>" class="btn btn-light btn-cart">
            <img src="<?php echo e(asset('images/icons/shop-dark.svg')); ?>">
        </a>

        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('my.account')); ?>" class="btn btn-light ms-3"><?php echo e(__('My Account')); ?></a>
            <a href="<?php echo e(route('my.logout')); ?>" class="btn btn-outline-light btn-cart">
                <i class="fa fa-sign-out-alt"></i>
            </a>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-light ms-3"><?php echo e(__('Login')); ?></a>
            <a href="<?php echo e(route('plans')); ?>" class="btn btn-light ms-3"><?php echo e(__('Sign Up')); ?></a>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /var/www/resources/views/layouts/site_menu.blade.php ENDPATH**/ ?>