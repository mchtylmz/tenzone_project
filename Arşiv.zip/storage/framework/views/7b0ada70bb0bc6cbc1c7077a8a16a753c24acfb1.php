<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Favicon -->
    <link rel="icon" href="<?php echo asset(settings()->site_favicon); ?>">

    <title><?php echo e($title); ?> - <?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css" type="text/css">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/auth.css'))); ?>">

    @livewireStyles

    <?php echo $__env->yieldPushContent('styles'); ?>

    <!-- Scripts -->
    <script>
        const lang = {
            unknown_error: '<?php echo e(__('message.unknown_error')); ?>',
        }
    </script>
    <script src="<?php echo e(asset(mix('js/auth.js'))); ?>" defer></script>
</head>
<body>
    <main class="<?php echo e($className); ?> page-100-center">
        <?php echo e($slot); ?>

    </main>

    <?php echo $__env->yieldPushContent('modals'); ?>

    @livewireScripts

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Users/mucahityilmaz/Desktop/Tenzone/resources/views/layouts/auth.blade.php ENDPATH**/ ?>