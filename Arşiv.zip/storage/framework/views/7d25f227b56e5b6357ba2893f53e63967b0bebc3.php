<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Favicon -->
    <link rel="icon" href="<?php echo asset(settings()->site_favicon); ?>">

    <title><?php echo e($title); ?> - <?php echo e(config('app.name', 'Tenzone')); ?></title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css" type="text/css">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/panel.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" />
    <link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/remixicon/remixicon.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldPushContent('styles'); ?>

    <!-- Scripts -->
    <script>
        const lang = {
            unknown_error: '<?php echo e(__('message.unknown_error')); ?>',
        }
    </script>
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</head>
<body>

<?php if(auth()->guard()->check()): ?>
    <nav class="tm-sidebar" id="tmSidenav">
        <div class="logo">
            <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="logo">
            <a href="javascript:void(0)" class="tm-sidebar-close"><i class="ri-close-line fs-24 text-dark"></i></a>
        </div>
        <div class="links">
            <ul class="list-unstyled">
                <?php echo $__env->make('panel.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </ul>
        </div>
        <div class="alt">
            <a href="javascript:;" class="btn btn-light btn-block btn-48">Tenzone Portal v1.0</a>
        </div>
    </nav>
<?php endif; ?>

<main class="main">
    <div class="tm-topbar flex-between items-center">
        <div class="left flex-start items-center">
            <a href="javascript:void(0)" class="tm-sidebar-open"><i class="ri-menu-line fs-24 text-dark"></i></a>
        </div>

        <div class="flex-end items-center">
            <div class="dropdown after-line">
                <a class="btn btn-icon" href="#" role="button" id="dropdownNotification" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="ri-notification-line"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-notification" aria-labelledby="dropdownNotification">

                    <li>
                        <div class="box flex-start">
                            <div class="icon bg-opacity-main"><i class="ri-information-line text-main"></i></div>
                            <div class="content">
                                <span class="title">Hello! This is an information notification.</span>
                                <span class="desc">This is the description field for more information</span>
                            </div>
                        </div>
                    </li>

                </ul>
            </div>

            <a class="btn btn-icon" href="<?php echo e(route('messages.seen')); ?>" role="button">
                <i class="ri-mail-open-line"></i>
            </a>

            <?php if(auth()->check() && auth()->user()->hasAnyRole('user')): ?>
            <a href="#" class="btn btn-opacity-success fs-14 fw-medium ms-4 me-3 credit">
                <?php echo e(user()->plan_credit); ?> Credit
            </a>
            <?php endif; ?>

            <div class="dropdown tm-topbar-profile">
                <a class="btn flex-start items-center" href="#" role="button" id="dropdownNotification" data-bs-toggle="dropdown" aria-expanded="false">
                    <div class="img"><img src="<?php echo e(asset('images/profile.png')); ?>" alt="profile"></div>
                    <div class="right">
                        <span class="name"><?php echo e(auth()->user()->fullname); ?></span>
                        <span class="desc"><?php echo e(__('role.' . auth()->user()->getRoleNames()[0])); ?></span>
                    </div>
                    <i class="ri-arrow-drop-down-line arrow"></i>
                </a>
                <ul class="dropdown-menu" aria-labelledby="dropdownNotification">
                    <li><a class="dropdown-item" href="<?php echo e(route('my.profile')); ?>">Profile</a></li>
                    <li><a class="dropdown-item" href="<?php echo e(route('messages.seen')); ?>">Messages</a></li>
                    <li><a class="dropdown-item" href="<?php echo e(route('my.logout')); ?>">Log out</a></li>
                </ul>
            </div>
        </div>

    </div>
    <div class="container-fluid pt-4">
        <?php echo e($slot); ?>

    </div>
</main>

<?php echo $__env->yieldPushContent('modals'); ?>
</body>
</html>
<?php /**PATH /var/www/resources/views/layouts/panel.blade.php ENDPATH**/ ?>