<?php if (isset($component)) { $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SiteLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SiteLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> home.css <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($product->title); ?> <?php $__env->endSlot(); ?>

    <section class="tz-page-normal">
        <div class="container">
            <div class="tz-shop-detail">
                <div class="row">
                    <div class="col-lg-5">
                        <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->title); ?>">
                    </div>
                    <div class="col-lg-7">
                        <div class="content">
                            <h1 class="productname"><?php echo e($product->title); ?></h1>
                            <div class="stars">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <img src="<?php echo e(asset('images/icons/star.svg')); ?>" alt="<?php echo e($i); ?>">
                                <?php endfor; ?>
                            </div>

                            <p class="text">
                                <?php echo e($product->content); ?>

                            </p>
                            <h2 class="price">£<?php echo e($product->price); ?></h2>

                            <form action="<?php echo e(route('cart.save', $product->id)); ?>" method="post">
                                <button type="submit" class="btn btn-primary">
                                    <img src="<?php echo e(asset('images/icons/shop-white.svg')); ?>" alt="<?php echo e($product->title); ?>">
                                    <?php echo e(__('Add to basket')); ?>

                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tz-shop-other">
                <div class="head">
                    <h2 class="head-title">Shop</h2>
                    <a href="<?php echo e(route('store')); ?>" class="link"><?php echo e(__('See All')); ?> <i class="fa fa-arrow-right"></i></a>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-6 col-xl-4">
                            <div class="tz-product-box">
                                <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->title); ?>" class="img">
                                <div class="content">
                                    <h3 class="name"><?php echo e($product->title); ?></h3>
                                    <span class="price">£<?php echo e($product->price); ?></span>
                                    <a href="<?php echo e(route('store.detail', $product->slug)); ?>" class="btn btn-primary">
                                        <img src="<?php echo e(asset('images/icons/shop2.svg')); ?>" alt="basket" class="primary">
                                        <img src="<?php echo e(asset('images/icons/shop-white.svg')); ?>" alt="basket" class="white">
                                        <?php echo e(__('Add to Basket')); ?>

                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311)): ?>
<?php $component = $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311; ?>
<?php unset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311); ?>
<?php endif; ?>
<?php /**PATH /Users/mucahityilmaz/Desktop/Tenzone/resources/views/site/store_detail.blade.php ENDPATH**/ ?>