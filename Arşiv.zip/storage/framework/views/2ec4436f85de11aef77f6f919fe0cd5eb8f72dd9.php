<?php if (isset($component)) { $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SiteLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SiteLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> default.css <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Help')); ?> <?php $__env->endSlot(); ?>

    <section class="tz-page">
        <div class="container containerarea">

            <div class="head-title text-center mb-100">
                <h1><?php echo e(__('Frequently asked Questions')); ?></h1>
                <img src="<?php echo e(asset('images/line.svg')); ?>" class="line">
            </div>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tz-help-box">
                    <h3 class="tz-help-title"><?php echo e(__('help.' . $category)); ?></h3>
                    <div class="accordion tz-accordion" id="accordion<?php echo e($category); ?>">
                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($faq->category == $category): ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="h<?php echo e($faq->id); ?>" data-bs-toggle="collapse" data-bs-target="#c<?php echo e($faq->id); ?>" aria-expanded="false" aria-controls="c<?php echo e($faq->id); ?>">
                                        <span><?php echo e($faq->title); ?></span>
                                        <i class="fa fa-plus" id="closed"></i>
                                        <i class="fa fa-minus" id="opened"></i>
                                    </h2>
                                    <div id="c<?php echo e($faq->id); ?>" class="accordion-collapse collapse" data-bs-parent="#accordion<?php echo e($category); ?>">
                                        <div class="accordion-body">
                                            <?php echo e($faq->content); ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311)): ?>
<?php $component = $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311; ?>
<?php unset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/site/help.blade.php ENDPATH**/ ?>