<script>
    const lang = {
        unknown_error: '<?php echo e(__('message.unknown_error')); ?>'
    }
</script>
<?php /**PATH /var/www/resources/views/components/scripts/translations.blade.php ENDPATH**/ ?>