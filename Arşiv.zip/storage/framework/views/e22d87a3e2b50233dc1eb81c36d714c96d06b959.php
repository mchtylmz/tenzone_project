<?php if (isset($component)) { $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SiteLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SiteLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> default.css <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Select Available time')); ?> <?php $__env->endSlot(); ?>

    <section class="tz-page">
        <div class="container containerarea">

            <div class="head-title text-center">
                <h1>Select Available time</h1>
                <img src="<?php echo e(asset('images/line.svg')); ?>" alt="line" class="line">
            </div>

            <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tz-time-box">
                    <div class="left">
                        <span class="text">
                            <img src="<?php echo e(asset('images/icons/calendar.svg')); ?>" alt="calendar">
                            <?php echo e($today); ?>

                        </span>
                    </div>
                    <div class="mid">
                        <span class="text">
                            <img src="<?php echo e(asset('images/icons/clock.svg')); ?>" alt="clock">
                            <?php echo e($time); ?>

                        </span>
                    </div>
                    <div class="right">
                        <a href="<?php echo e(route('confirm.time', strtotime($time))); ?>" class="btn btn-outline-primary">Book</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311)): ?>
<?php $component = $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311; ?>
<?php unset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/site/select_time.blade.php ENDPATH**/ ?>