<script>
    const lang = {
        unknown_error: '<?php echo e(__('message.unknown_error')); ?>'
    }
</script>
<?php /**PATH /Users/mucahityilmaz/Desktop/Tenzone/resources/views/components/scripts/translations.blade.php ENDPATH**/ ?>