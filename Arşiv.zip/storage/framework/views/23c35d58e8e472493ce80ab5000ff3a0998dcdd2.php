<?php if(auth()->check() && auth()->user()->hasAnyRole('user')): ?>
    <?php foreach($attributes->onlyProps(['prefix' => 'user']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['prefix' => 'user']); ?>
<?php foreach (array_filter((['prefix' => 'user']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php endif; ?>

<?php if(auth()->check() && auth()->user()->hasAnyRole('parent')): ?>
    <?php foreach($attributes->onlyProps(['prefix' => 'parent']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['prefix' => 'parent']); ?>
<?php foreach (array_filter((['prefix' => 'parent']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php endif; ?>

<?php if(auth()->check() && auth()->user()->hasAnyRole('teacher')): ?>
    <?php foreach($attributes->onlyProps(['prefix' => 'teacher']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['prefix' => 'teacher']); ?>
<?php foreach (array_filter((['prefix' => 'teacher']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php endif; ?>

<?php if(auth()->check() && auth()->user()->hasAnyRole('theraphy')): ?>
    <?php foreach($attributes->onlyProps(['prefix' => 'theraphy']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['prefix' => 'theraphy']); ?>
<?php foreach (array_filter((['prefix' => 'theraphy']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php endif; ?>

<?php if(auth()->check() && auth()->user()->hasAnyRole('superadmin|admin')): ?>

<li>
    <a href="programme.html" class="active">
        <div class="icon"><i class="ri-file-list-2-line"></i></div>
        ADMİN
    </a>
</li>

<?php else: ?>

<li>
    <a href="<?php echo e(route($prefix . '.index')); ?>" class="<?php echo e(in_array(request()->route()->getName(), [$prefix . '.index', $prefix . '.child_programme']) ? 'active':''); ?>">
        <div class="icon"><i class="ri-file-list-2-line"></i></div>
        Programme
    </a>
</li>
<li>
    <a href="<?php echo e(route($prefix . '.reports')); ?>" class="<?php echo e(request()->route()->getName() == $prefix . '.reports' ? 'active':''); ?>">
        <div class="icon"><i class="ri-funds-box-line"></i></div>
        Reports
    </a>
</li>
<li>
    <a href="<?php echo e(route($prefix . '.connect')); ?>" class="<?php echo e(request()->route()->getName() == $prefix . '.connect' ? 'active':''); ?>">
        <div class="icon"><i class="ri-chat-smile-2-line"></i></div>
        Connect
    </a>
</li>

<?php endif; ?>



<?php /**PATH /var/www/resources/views/panel/menu.blade.php ENDPATH**/ ?>