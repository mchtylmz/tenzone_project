<?php if (isset($component)) { $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SiteLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SiteLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> default.css <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Booking Completed')); ?> <?php $__env->endSlot(); ?>

    <section class="tz-page-normal">
        <div class="container containerarea">

            <div class="tz-payment-confirm">

                <div class="top text-center">
                    <img src="<?php echo e(asset('images/confirm.gif')); ?>" alt="confirm">
                    <h2 class="text-title">Your boking has been received.</h2>
                    <h3 class="text-subtitle">We will notify you by e-mail when your booking is status.</h3>
                </div>

                <table class="table table-summary mb-0 mt-4">
                    <tfoot>
                    <tr>
                        <td>Booking Date</td>
                        <td><?php echo e($bookdate); ?></td>
                    </tr>
                    <tr>
                        <td>Booking Time</td>
                        <td><?php echo e($booktime); ?></td>
                    </tr>
                    </tfoot>
                </table>

            </div>

        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311)): ?>
<?php $component = $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311; ?>
<?php unset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/site/book_completed.blade.php ENDPATH**/ ?>