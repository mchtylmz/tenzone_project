<?php if (isset($component)) { $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SiteLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SiteLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> home.css <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Blogs')); ?> <?php $__env->endSlot(); ?>

    <section class="pb-5 mb-5 pt-0">
        <div class="container pt-5">
            <div class="relative pt-5">
                <h2 class="head-title inline-block"><?php echo e(__('Blogs')); ?></h2>
            </div>
            <div class="row mt-4 mb-4 justify-content-start">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 p-3">
                        <div class="blog-item blog-hover">
                            <div class="relative bg-danger" style="margin-top:36px !important">
                                <img src="<?php echo e($blog->image); ?>" alt="blog">
                            </div>
                            <div class="content pe-3">
                                <a href="<?php echo e(route('blog.detail', $blog->slug)); ?>">
                                    <h6 class="title text-start text-dark" style="padding-left: 38px !important;">
                                        <?php echo e($blog->title); ?>

                                    </h6>
                                </a>
                                <a href="<?php echo e(route('blog.detail', $blog->slug)); ?>">
                                    <p class="text-start text-dark" style="padding-left: 38px !important;">
                                        <?php echo e($blog->brief); ?>

                                    </p>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($blogs->links()); ?>

        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311)): ?>
<?php $component = $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311; ?>
<?php unset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311); ?>
<?php endif; ?>
<?php /**PATH /Users/mucahityilmaz/Desktop/Tenzone/resources/views/site/blog.blade.php ENDPATH**/ ?>