<?php if (isset($component)) { $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SiteLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SiteLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> default.css <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Confirm Plan')); ?> <?php $__env->endSlot(); ?>

    <section class="tz-page-normal">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <h2 class="head-title">Plan Details</h2>
                    <div class="tz-payment-box mb-4">

                        <form id="payment-form" action="<?php echo e(route('plan.checkout', $plan->slug)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="plan" id="plan" value="<?php echo e($plan->stripe_plan); ?>">

                            <div class="mb-4 position-relative">
                                <label for="">Card Holder Name</label>
                                <input type="text" id="card-holder-name" name="cardname" class="form-control" placeholder="XXXXXXX" required>
                            </div>
                            <div class="form-group">
                                <label for="">Card details</label>
                                <div id="payment-element"></div>
                            </div>

                            <button id="card-button" data-secret="<?php echo e($intent->client_secret); ?>" type="submit" class="btn btn-primary opacity btn-block mt-4">Confirm Plan</button>

                        </form>
                        <script src="https://js.stripe.com/v3/"></script>

                        <script>
                            const stripe = Stripe('<?php echo e(config('stripe.publishable_key')); ?>')
                            const options = {
                                clientSecret: '<?php echo e($intent->client_secret); ?>',
                                // Fully customizable with appearance API.
                                appearance: {
                                    theme: 'stripe',
                                    labels: 'floating',
                                },
                            };

                            const elements = stripe.elements(options)
                            const cardElement = elements.create('card')

                            cardElement.mount('#payment-element')

                            const form = document.getElementById('payment-form')
                            const cardBtn = document.getElementById('card-button')
                            const cardHolderName = document.getElementById('card-holder-name')

                            form.addEventListener('submit', async (e) => {
                                e.preventDefault()

                                cardBtn.disabled = true
                                const { setupIntent, error } = await stripe.confirmCardSetup(
                                    cardBtn.dataset.secret, {
                                        payment_method: {
                                            card: cardElement,
                                            billing_details: {
                                                name: cardHolderName.value
                                            }
                                        }
                                    }
                                )

                                if(error) {
                                    cardBtn.disable = false
                                } else {
                                    let token = document.createElement('input')

                                    token.setAttribute('type', 'hidden')
                                    token.setAttribute('name', 'token')
                                    token.setAttribute('value', setupIntent.payment_method)

                                    form.appendChild(token)

                                    form.submit();
                                    cardBtn.disable = false
                                }
                            })
                        </script>

                    </div>

                </div>

                <div class="col-lg-4">
                    <h2 class="head-title z-1">Your Plan</h2>
                    <div class="tz-payment-box mb-4">

                        <div class="tz-product-item">
                            <div class="content">
                                <h2 class="name"><?php echo e($plan->name); ?></h2>
                                <h3 class="price">£<?php echo e($plan->price); ?></h3>
                                <span class="quantity">
                                    <?php if($plan->type == 'monthly'): ?>
                                        /Monthly
                                    <?php else: ?>
                                        /Yearly
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>
                        <table class="table table-summary mb-0">
                            <tfoot>
                            <tr>
                                <td>Total</td>
                                <td>£<?php echo e($plan->price); ?></td>
                            </tr>
                            </tfoot>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311)): ?>
<?php $component = $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311; ?>
<?php unset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/site/plan_subscribe.blade.php ENDPATH**/ ?>