<?php if (isset($component)) { $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PanelLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\PanelLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Child Programme')); ?> <?php $__env->endSlot(); ?>

    <div class="tm-page-head">
        <h1 class="title"><?php echo e($child->fullname); ?> Programme</h1>
        <p class="text mb-0">You can see your scheduled programs here.</p>
    </div>

    <?php if(session('message')): ?>
        <div class="alert alert-info"><?php echo e(session('message')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="row">

        <div class="tm-calendar tm-calendar2">
            <div class="row g-0">

                <div class="col-lg-2">
                    <div class="nav-scroll">
                        <div class="nav flex-column nav-pills week_section" id="calendar" role="tablist" aria-orientation="vertical">
                            <?php $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button class="nav-link <?php echo e($loop->index == 0 ? 'active':''); ?>" id="id-week<?php echo e($week->id); ?>" data-bs-toggle="pill" data-bs-target="#week<?php echo e($week->id); ?>" type="button" role="tab" aria-controls="week<?php echo e($week->id); ?>" aria-selected="true">
                                    <h4 class="title"><?php echo e($week->title); ?></h4>
                                    <span class="date">
                                        <?php echo e(date('d', strtotime($week->start_date))); ?> -
                                        <?php echo e(date('d M', strtotime($week->end_date))); ?>

                                    </span>
                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <a href="#modalAddWeek" class="btn btn-primary w-100 my-3" data-bs-target="#modalAddWeek" data-bs-toggle="modal">
                        Add Week
                    </a>
                </div>

                <div class="col-lg-10">
                    <div class="tab-content bg-white" id="calendarContent">
                        <?php $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane fade <?php echo e($loop->index == 0 ? 'show active':''); ?>"
                                 id="week<?php echo e($week->id); ?>" role="tabpanel">


                                <?php $__currentLoopData = $week->activities()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tm-calendar-item flex-between items-center">
                                        <div class="left flex-start items-center">
                                            <div class="text text-main">
                                                <?php echo e($activite->teacher()->first()->fullname); ?>

                                            </div>
                                            <div class="text"><?php echo e($activite->title); ?></div>
                                            <div class="text"><?php echo e($activite->type); ?></div>
                                        </div>
                                        <div class="right flex-end items-center">
                                            <?php if($activite->download): ?>
                                                <a target="_blank" href="<?php echo asset($activite->download); ?>"
                                                   class="btn">
                                                    <i class="ri-download-cloud-line"></i> Download
                                                </a>
                                            <?php endif; ?>
                                            <?php if($activite->watch): ?>
                                                <a target="_blank" href="<?php echo asset($activite->watch); ?>" class="btn">
                                                    <i class="ri-play-circle-line"></i> Watch
                                                </a>
                                            <?php endif; ?>
                                            <?php if($submission = $activite->submission()->first()): ?>
                                                <a target="_blank" href="<?php echo asset($submission->file); ?>" class="btn">
                                                    <i class="ri-download-cloud-line"></i>
                                                    View Submission
                                                </a>
                                            <?php endif; ?>
                                            <?php if($activite->teacher_id == auth()->user()->id): ?>
                                                <form onsubmit="return confirm('<?php echo e(__('Activite is delete ?')); ?>')" action="<?php echo e(route('teacher.delete.activite', $activite->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn">
                                                        <i class="ri-delete-bin-4-line me-0"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <a href="#modalAddActivity<?php echo e($week->id); ?>" data-bs-target="#modalAddActivity<?php echo e($week->id); ?>" data-bs-toggle="modal"
                                   class="btn btn-block btn-primary mt-3">
                                    Add Week Activity
                                </a>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.add_activity','data' => ['week' => ''.e($week->id).'','weekTitle' => ''.e($week->title).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('add_activity'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['week' => ''.e($week->id).'','weekTitle' => ''.e($week->title).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

        </div>

    </div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.add_week','data' => ['child' => ''.e($child->id).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('add_week'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['child' => ''.e($child->id).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937)): ?>
<?php $component = $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937; ?>
<?php unset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/panel/teacher/programme.blade.php ENDPATH**/ ?>