<?php if (isset($component)) { $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SiteLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SiteLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> home.css <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Store')); ?> <?php $__env->endSlot(); ?>

    <section class="tz-page-normal tz-shop">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 mobile-hide">
                    <h2 class="head-title"><?php echo e(__('Filter')); ?></h2>
                    <div class="tz-filter-box">
                        <h3 class="title"><?php echo e(__('Category')); ?></h3>
                        <div class="form-check">
                            <label class="form-check-label" for="categoryAll" onclick="window.location.href='?all'">
                                <?php echo e(__('store.category_all')); ?>

                            </label>
                        </div>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" id="category<?php echo e($loop->index); ?>" onclick="window.location.href='?category=<?php echo e($category); ?>'" <?php echo e($checked_category == $category ? 'checked':''); ?>>
                                <label class="form-check-label" for="category<?php echo e($loop->index); ?>">
                                    <?php echo e(__('store.'.$category)); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="col-lg-9">
                    <div class="flex-between">
                        <h2 class="head-title"><?php echo e(__('Products')); ?></h2>
                        <a href="#modalFilter" data-bs-toggle="modal" data-bs-target="#modalFilter" class="link-filter mobile-show"><?php echo e(__('Filter')); ?> <img src="<?php echo e(asset('images/icons/filter-fill.svg')); ?>" alt="filter"></a>
                    </div>
                    <div class="row mb-4">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-lg-6 col-xl-4">
                                <div class="tz-product-box">
                                    <img src="<?php echo e($product->image); ?>" class="img">
                                    <div class="content">
                                        <h3 class="name"><?php echo e($product->title); ?></h3>
                                        <span class="price">£<?php echo e($product->price); ?></span>
                                        <a href="<?php echo e(route('store.detail', $product->slug)); ?>" class="btn btn-primary">
                                            <img src="<?php echo e(asset('images/icons/shop2.svg')); ?>" alt="basket" class="primary">
                                            <img src="<?php echo e(asset('images/icons/shop-white.svg')); ?>" alt="basket" class="white">
                                            <?php echo e(__('Add to Basket')); ?>

                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </section>

    <div class="modal fade" id="modalFilter" tabindex="-1" aria-labelledby="modalFilter" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e(__('Filter')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="tz-filter-box border-bottom-f1">
                        <h3 class="title"><?php echo e(__('Category')); ?></h3>
                        <div class="form-check">
                            <label class="form-check-label" for="categoryAll" onclick="window.location.href='?all'">
                                <?php echo e(__('store.category_all')); ?>

                            </label>
                        </div>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" id="category<?php echo e($loop->index); ?>" onclick="window.location.href='?category=<?php echo e($category); ?>'" <?php echo e($checked_category == $category ? 'checked':''); ?>>
                                <label class="form-check-label" for="category<?php echo e($loop->index); ?>">
                                    <?php echo e(__('store.'.$category)); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311)): ?>
<?php $component = $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311; ?>
<?php unset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311); ?>
<?php endif; ?>
<?php /**PATH /Users/mucahityilmaz/Desktop/Tenzone/resources/views/site/store.blade.php ENDPATH**/ ?>