<?php if (isset($component)) { $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SiteLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SiteLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> default.css <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Carts')); ?> <?php $__env->endSlot(); ?>

    <section class="tz-page-normal">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <h2 class="head-title">Personal Details</h2>
                    <div class="tz-payment-box mb-4">
                        <div class="head">
                            <h3 class="title">Shipping</h3>
                            <img src="<?php echo e(asset('images/icons/user.svg')); ?>" alt="user">

                        </div>

                        <form action="<?php echo e(route('cart.checkout')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="">First Name *</label>
                                        <input type="text" name="firstname" class="form-control" placeholder="Michael"required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="">Last Name *</label>
                                        <input type="text" name="lastname" class="form-control" placeholder="Smith"required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-4">
                                        <label for="">Email Address *</label>
                                        <input type="email" name="email" class="form-control" placeholder="Michael"required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="">Address *</label>
                                        <input type="text" name="address" class="form-control"
                                               placeholder="2715 Ash Dr. San Jose, South Dakota 83475"required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="">Phone *</label>
                                        <input type="text" name="phone" class="form-control" placeholder="+90 625 86 89"required>
                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="">City *</label>
                                        <input type="text" name="city" class="form-control" placeholder="Royal Ln. Mesa"required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="">Country *</label>
                                        <input type="text" name="country" class="form-control" placeholder=" New Jersey" required>
                                    </div>
                                </div>
                            </div>


                            <div class="head">
                                <h3 class="title">Payment</h3>
                                <img src="<?php echo e(asset('images/icons/bank-card.svg')); ?>" alt="bank">
                            </div>

                            <div class="mb-4 position-relative">
                                <label for="">Card Holder Name</label>
                                <input type="text" name="cardname" class="form-control" placeholder="XXXXXXX" required>
                            </div>

                            <div class="mb-4 position-relative">
                                <label for="">Card Number</label>
                                <input type="text" name="cardnumber" minlength="14" maxlength="21" class="form-control" placeholder="124246237921239" required>
                                <img src="<?php echo e(asset('images/banks.png')); ?>" alt="banks" class="img-banks">
                            </div>

                            <div class="row">
                                <div class="col-3">
                                    <div class="mb-4">
                                        <label for="">Expiry Month (MM)</label>
                                        <select name="expmonth" class="form-control" required>
                                            <?php for($month = 1; $month <= 12; $month++): ?>
                                                <?php if($month <= 9): ?>
                                                    <option value="0<?php echo e($month); ?>">0<?php echo e($month); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($month); ?>"><?php echo e($month); ?></option>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="mb-4">
                                        <label for="">Expiry Year (YY)</label>
                                        <select name="expyear" class="form-control" required>
                                            <?php for($year = 0; $year <= 10; $year++): ?>
                                                <option value="<?php echo e(date('y', strtotime($year . ' years'))); ?>">
                                                    <?php echo e(date('Y', strtotime($year . ' years'))); ?>

                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-3"></div>
                                <div class="col-3">
                                    <div class="mb-4">
                                        <label for="">CVC</label>
                                        <input type="text" name="cvc" maxlength="4" class="form-control" placeholder="CVC" required>
                                    </div>
                                </div>
                            </div>

                                <button id="submit" type="submit" class="btn btn-primary opacity btn-block mt-4">Confirm Payment</button>

                        </form>

                    </div>

                </div>

                <div class="col-lg-4">
                    <h2 class="head-title z-1">Your Order</h2>
                    <div class="tz-payment-box mb-4">

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tz-product-item">
                                <div class="img"><img src="<?php echo e($product->image); ?>" alt="image"></div>
                                <div class="content">
                                    <h2 class="name"><?php echo e($product->title); ?></h2>
                                    <h3 class="price">£<?php echo e($product->price); ?></h3>
                                    <span class="quantity">Quantity: 1</span>
                                </div>
                                <form action="<?php echo e(route('cart.delete', $product->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="delete" style="background: transparent; border:none">
                                        <img src="<?php echo e(asset('images/icons/delete.svg')); ?>" alt="<?php echo e($product->title); ?>">
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <table class="table table-summary mb-0">
                            <tfoot>
                            <tr>
                                <td>Total</td>
                                <td>£<?php echo e($total); ?></td>
                            </tr>
                            </tfoot>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311)): ?>
<?php $component = $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311; ?>
<?php unset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/site/cart.blade.php ENDPATH**/ ?>