<?php if (isset($component)) { $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SiteLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SiteLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> default.css <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Understanding your requirement')); ?> <?php $__env->endSlot(); ?>

    <section class="tz-page">
        <div class="container containerarea">

            <div class="head-title text-center">
                <h1>Understanding your requirement</h1>
                <img src="<?php echo e(asset('images/line.svg')); ?>" alt="line" class="line">
            </div>

            <form action="<?php echo e(route('book.free')); ?>" method="post" class="form-question">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label for="input1">Google Anlytics reads like a seismic chart lately</label>
                    <input type="hidden" name="question" value="Google Anlytics reads like a seismic chart lately">
                    <input type="text" name="answer" class="form-control" placeholder="Activity Sheets">
                </div>

                <div class="mb-4">
                    <label for="input1">Google Anlytics reads like a seismic chart lately</label>
                    <div class="row">
                        <div class="col-md-3">
                            <input type="radio" class="btn-check" name="options" id="option1" autocomplete="off">
                            <label class="btn btn-light zt-checkbtn btn-block" for="option1">Activity Sheets</label>
                        </div>
                        <div class="col-md-3">
                            <input type="radio" class="btn-check" name="options" id="option2" autocomplete="off">
                            <label class="btn btn-light zt-checkbtn btn-block" for="option2">Activity Sheets</label>
                        </div>
                        <div class="col-md-3">
                            <input type="radio" class="btn-check" name="options" id="option3" autocomplete="off">
                            <label class="btn btn-light zt-checkbtn btn-block" for="option3">Activity Sheets</label>
                        </div>
                        <div class="col-md-3">
                            <input type="radio" class="btn-check" name="options" id="option4" autocomplete="off">
                            <label class="btn btn-light zt-checkbtn btn-block" for="option4">Activity Sheets</label>
                        </div>
                    </div>
                </div>

                <div class="mb-4">
                    <label for="input1">Google Anlytics reads like a seismic chart lately</label>
                    <select class="form-select" aria-label="Default select example">
                        <option selected>Activity Sheets</option>
                        <option value="1">One</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                    </select>
                </div>

                <div class="mb-4">
                    <label for="input1">Google Anlytics reads like a seismic chart lately</label>
                    <input type="text" class="form-control" placeholder="Activity Sheets">
                </div>

                <button type="submit" class="btn btn-primary btn-block btn-icon-hover">Book a session for free <i class="fa fa-arrow-right"></i></button>
            </form>

        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311)): ?>
<?php $component = $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311; ?>
<?php unset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/site/book_free.blade.php ENDPATH**/ ?>