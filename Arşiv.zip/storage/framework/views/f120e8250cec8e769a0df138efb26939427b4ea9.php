<?php if (isset($component)) { $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PanelLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\PanelLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Admin Home')); ?> <?php $__env->endSlot(); ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937)): ?>
<?php $component = $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937; ?>
<?php unset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/panel/admin/welcome.blade.php ENDPATH**/ ?>