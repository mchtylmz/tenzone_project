<?php if (isset($component)) { $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SiteLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SiteLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> default.css <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($service->name); ?> <?php $__env->endSlot(); ?>

    <div class="tz-banner">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5">
                    <div class="content">
                        <h1 class="title"><?php echo e($service->name); ?>..</h1>
                        <p class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras fringilla id quam
                            ut lacinia. Nulla ullamcorper luctus ex, in sodales enim sollicitudin ac</p>
                        <a href="#" class="btn btn-primary">Book a session for free</a>
                    </div>
                </div>


                <div class="col-lg-6">
                    <img src="<?php echo e(asset('images/images.png')); ?>" alt="images" class="mt-4 mb-4 mobile-show">
                    <div class="position-relative tz-banner-animation mobile-hide">
                        <img src="<?php echo e(asset('images/animation/ellipse1.svg')); ?>" alt="img" class="flip-diagonal-2-br">
                        <img src="<?php echo e(asset('images/animation/img1.svg')); ?>" alt="img" class="anima-top anima-top1">
                        <img src="<?php echo e(asset('images/animation/pyramid.svg')); ?>" alt="img" class="anima-bottom">
                        <img src="<?php echo e(asset('images/animation/img2.svg')); ?>" alt="img" class="slide-tl">
                        <img src="<?php echo e(asset('images/animation/img3.svg')); ?>" alt="img" class="anima-top anima-top2">
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="tz-overview">
            <img src="<?php echo e(asset('images/line.png')); ?>" alt="line" class="line">
            <h2 class="title">Overview</h2>
            <h3 class="subtitle">Neque convallis a cras semper auctor. Libero id faucibus nisl tincidunt egetnvallis a
                cras semper auctonvallis a cras semper aucto.</h3>
            <p class="text mb-0">Neque convallis a cras semper auctor. Liberoe convallis a cras semper atincidunt
                egeeque convallis a cras semper auctor. Libero id faucibus nisl tincidunt egetnvallis a cras semper
                auctonvallis a cras semper aucto. Neque convallis a cras semper auctor. Liberoe convallis a cras semper
                atincidunt egetnval</p>
        </div>
    </div>


    <section class="tz-how">
        <div class="container"><h2 class="head-title">How it works</h2></div>
        <div class="container-fluid">
            <div class="owl-carousel owl-theme" id="tz-slider-how">
                <div class="item">
                    <div class="tz-how-box one">
                        <div class="number">
                            <img src="<?php echo e(asset('images/icons/1.svg')); ?>" alt="1">
                            <span style="color:#4060AA">1</span>
                        </div>

                        <div class="content">
                            <h3 class="title">Content</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet,
                                consectetur adipiscing elit.</p>
                        </div>
                    </div>
                </div>


                <div class="item">
                    <div class="tz-how-box two">
                        <div class="number">
                            <img src="<?php echo e(asset('images/icons/2.svg')); ?>" alt="1">
                            <span style="color:#EC673B">2</span>
                        </div>

                        <div class="content">
                            <h3 class="title">Content</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet,
                                consectetur adipiscing elit.</p>
                        </div>
                    </div>
                </div>


                <div class="item">
                    <div class="tz-how-box three">
                        <div class="number">
                            <img src="<?php echo e(asset('images/icons/3.svg')); ?>" alt="1">
                            <span style="color:#224644">3</span>
                        </div>

                        <div class="content">
                            <h3 class="title">Content</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet,
                                consectetur adipiscing elit.</p>
                        </div>
                    </div>
                </div>


                <div class="item">
                    <div class="tz-how-box four">
                        <div class="number">
                            <img src="<?php echo e(asset('images/icons/4.svg')); ?>" alt="1">
                            <span style="color:#DEB343">4</span>
                        </div>

                        <div class="content">
                            <h3 class="title">Content</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet,
                                consectetur adipiscing elit.</p>
                        </div>
                    </div>
                </div>


                <div class="item">
                    <div class="tz-how-box five">
                        <div class="number">
                            <img src="<?php echo e(asset('images/icons/5.svg')); ?>" alt="1">
                            <span style="color:#5D5FEF">5</span>
                        </div>

                        <div class="content">
                            <h3 class="title">Content</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet,
                                consectetur adipiscing elit.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>


    <section class="tz-what mobile-hide">
        <div class="container">
            <h2 class="head-title">What you get?</h2>
            <div class="row">
                <?php for($i = 0; $i <4; $i++): ?>
                    <div class="col-lg-6">
                        <div class="tz-blog-box">
                            <img src="<?php echo e(asset('images/blog.png')); ?>" alt="blog">
                            <div class="content">
                                <span class="tags">Education</span>
                                <h3 class="title">Weeklyly Activity plans</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet,
                                    consectetur adipiscing elit.</p>
                            </div>
                        </div>
                    </div>
                <?php endfor; ?>

            </div>
        </div>
    </section>


    <section class="tz-what mobile-show">
        <div class="container">
            <h2 class="head-title">What you get?</h2>
            <div class="owl-carousel owl-theme" id="tz-slider-what-mobile">

                <?php for($i = 0; $i <4; $i++): ?>
                    <div class="item">
                        <div class="tz-blog-box">
                            <img src="<?php echo e(asset('images/blog.png')); ?>" alt="blog">
                            <div class="content">
                                <span class="tags">Education</span>
                                <h3 class="title">Weeklyly Activity plans</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet,
                                    consectetur adipiscing elit.</p>
                            </div>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
    </section>


    <div class="container">
        <div class="tz-overview2">
            <div class="row">
                <div class="col-lg-8">
                    <div class="content">
                        <h2 class="title">You are not sure about our services</h2>
                        <p>The generated Lorem Ipsum is therefore always free from repetition, injected humour, or
                            non-characteristic words etc.</p>
                        <a href="#" class="btn btn-light">Book a session for free <i class="fa fa-arrow-right"></i></a>
                    </div>
                </div>

                <div class="col-lg-4 mobile-hide">
                    <div class="images">
                        <div class="position-relative">
                            <img src="<?php echo e(asset('images/image.png')); ?>" alt="image" class="img1">
                            <img src="<?php echo e(asset('images/image2.png')); ?>" alt="image" class="img2">
                            <img src="<?php echo e(asset('images/ellipse1.png')); ?>" alt="image" class="img3">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="tz-membership">
        <div class="container">
            <div class="text-center">
                <h2 class="head-title">Upgrade your membership</h2>
                <ul class="tz-membernav nav nav-pills justify-content-center mb-5" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="id-monthly" data-bs-toggle="pill"
                                data-bs-target="#tab-monthly" type="button" role="tab" aria-controls="tab-monthly"
                                aria-selected="true">Monthly
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="id-annually" data-bs-toggle="pill" data-bs-target="#tab-annually"
                                type="button" role="tab" aria-controls="tab-annually" aria-selected="false">Annually
                        </button>
                    </li>
                </ul>
            </div>
            <div class="tab-content" id="pills-tabContent">
                <div class="tab-pane fade show active" id="tab-monthly" role="tabpanel">
                    <div class="owl-carousel owl-theme" id="tz-slider-membership">
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($plan->type == 'monthly'): ?>
                                <div class="item">
                                    <div class="tz-pricing">
                                        <h3 class="name"><?php echo e($plan->name); ?></h3>
                                        <h4 class="price" style="color:#4060AA">£<?php echo e(number_format($plan->price, 0)); ?> <span>/month</span></h4>
                                        <span class="list-title">What You'll Get</span>
                                        <ul class="list-unstyled">
                                            <li>Activity Sheets</li>
                                            <li>Worksheets</li>
                                            <li>Weekly Feedback</li>
                                        </ul>
                                        <a href="<?php echo e(route('register', [$plan->slug, 1])); ?>" class="btn btn-outline-primary btn-block">
                                            Choose
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="tab-pane fade" id="tab-annually" role="tabpanel">
                    <div class="owl-carousel owl-theme" id="tz-slider-membership2">
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($plan->type == 'yearly'): ?>
                                <div class="item">
                                    <div class="tz-pricing">
                                        <h3 class="name"><?php echo e($plan->name); ?></h3>
                                        <h4 class="price" style="color:#4060AA">£<?php echo e(number_format($plan->price / 12, 0)); ?> <span>/month</span></h4>
                                        <span class="list-title">What You'll Get</span>
                                        <ul class="list-unstyled">
                                            <li>Activity Sheets</li>
                                            <li>Worksheets</li>
                                            <li>Weekly Feedback</li>
                                        </ul>
                                        <a href="<?php echo e(route('register', [$plan->slug, 12])); ?>" class="btn btn-outline-primary btn-block">
                                            Choose
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="tz-testimonials">
        <div class="container"><h2 class="head-title text-center">Testimonials</h2></div>
        <div class="container-fluid">
            <div class="owl-carousel owl-theme" id="tz-slider-comments">
                <?php for($i = 0; $i <= 4; $i++): ?>
                    <div class="item">
                        <div class="tz-comment">
                            <img src="<?php echo e(asset('images/icons/comment.png')); ?>" alt="comment" class="icon">
                            <p class="text">Nulla Lorem mollit cupidatat irure. Laborum magna nulla duis ullamco cillum
                                dolor. Voluptate exercitation incididunt aliquip deserunt reprehenderit elit laborum.</p>
                            <div class="profile flex-start">
                                <img src="<?php echo e(asset('images/profile.png')); ?>" alt="profile">
                                <div class="content">
                                    <span class="name">Cameron Williamson</span>
                                    <span class="mini">President of Sales</span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311)): ?>
<?php $component = $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311; ?>
<?php unset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311); ?>
<?php endif; ?>
<?php /**PATH /Users/mucahityilmaz/Desktop/Tenzone/resources/views/site/service/educational.blade.php ENDPATH**/ ?>