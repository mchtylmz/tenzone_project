<?php if (isset($component)) { $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PanelLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\PanelLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Add Child')); ?> <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-lg-4">
            <?php if(childs()): ?>
                <div class="tm-profile-card py-3 mb-20px">
                    <?php $__currentLoopData = childs(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('user.profile', $child->email)); ?>" class="tm-profile-btn student">
                            <img src="<?php echo e(asset('images/profile.png')); ?>" alt="profile">
                            <?php echo e($child->fullname); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

        </div>

        <div class="col-lg-8">
            <div class="tm-profile-card tm-profile-content">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <h4 class="bg-light p-2 mb-3">
                    <?php echo e(__('Child Add')); ?>

                </h4>
                <form action="<?php echo e(route('parent.child.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label>Name</label>
                        <div class="tm-input">
                            <div class="icon"><i class="ri-user-line"></i></div>
                            <input type="text" name="name" required class="form-control" value="<?php echo e(old('name')); ?>" placeholder="Name">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label>Surname</label>
                        <div class="tm-input">
                            <div class="icon"><i class="ri-user-line"></i></div>
                            <input type="text" name="surname" value="<?php echo e(old('surname')); ?>" required class="form-control" placeholder="Surname">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label>Password</label>
                        <div class="tm-input">
                            <div class="icon"><i class="ri-user-line"></i></div>
                            <input type="password" name="password" required class="form-control" placeholder="******">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label>Date of birth <span class="text-main">*</span></label>
                        <div class="tm-input">
                            <div class="icon"><i class="ri-calendar-2-fill"></i></div>
                            <input type="text" class="form-control datepicker" value="<?php echo e(old('dob')); ?>" name="dob" required placeholder="Date of birth">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label>Gender <span class="text-main">*</span></label>
                        <div class="btn-group tm-btn-group w-190" role="group" aria-label="Basic radio toggle button group">

                            <input type="radio" class="btn-check" name="gender" id="btnradio1" value="male" autocomplete="off" <?php echo e(old('gender') == 'male' ? 'checked':''); ?> required>
                            <label class="tm-checkbtn btn btn-light btn-48" for="btnradio1">Male</label>

                            <input type="radio" class="btn-check" name="gender" id="btnradio2" value="female" autocomplete="off" <?php echo e(old('gender') == 'female' ? 'checked':''); ?> required>
                            <label class="tm-checkbtn btn btn-light btn-48" for="btnradio2">Female</label>

                        </div>
                    </div>

                    <div class="mb-3">
                        <label>Email Address <span class="text-main">*</span></label>
                        <div class="tm-input">
                            <div class="icon"><i class="ri-mail-open-line"></i></div>
                            <input type="text" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Email address" name="email" required >
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block btn-icon-hover">Save <i class="fa fa-arrow-right"></i></button>

                </form>
            </div>
        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937)): ?>
<?php $component = $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937; ?>
<?php unset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/panel/parent/child_add.blade.php ENDPATH**/ ?>