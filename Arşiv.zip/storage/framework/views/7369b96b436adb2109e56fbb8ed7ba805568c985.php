<?php if (isset($component)) { $__componentOriginal7b6721487b7b8dd63e67398e09f7d70f121b9aa3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AuthLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AuthLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('class', null, []); ?> login <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Login')); ?> <?php $__env->endSlot(); ?>

    <div class="container-fluid p-0 h-100">
        <div class="row g-0 h-100">

            <div class="col-lg-6 h-100 dmn">
                <div class="tm-login-background h-100">
                    <img src="<?php echo e(asset('images/background.jpg')); ?>" alt="login" class="cover">
                    <div class="content">
                        <h2 class="title">We scratch, build and <br>play together</h2>
                        <p>The TEN Academy is an online platform for individuals with autism and their families.</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 h-100">
                <div class="vertical-center h-100">
                    <div class="tm-lb-form">
                        <img src="<?php echo e(asset('images/logo-icon.svg')); ?>" alt="icon" class="mb-3">
                        <h1 class="title mb-1">Login</h1>
                        <p class="text text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                        <form id="login" method="POST" action="<?php echo e(route('login')); ?>" class="loading">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label>Email Address <span class="text-main">*</span></label>
                                <div class="tm-input">
                                    <div class="icon"><i class="ri-mail-open-line"></i></div>
                                    <input type="email" name="email" class="form-control" placeholder="Email address">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label>Password <span class="text-main">*</span></label>
                                <div class="tm-input">
                                    <div class="icon"><i class="ri-lock-password-line"></i></div>
                                    <input type="password" name="password" class="form-control" placeholder="********">
                                </div>
                            </div>

                            <?php if(Route::has('password.request')): ?>
                                <div class="mb-3">
                                    <a class="text-muted text-xs" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot your password?')); ?>

                                    </a>
                                </div>
                            <?php endif; ?>

                            <button type="submit" class="btn btn-primary btn-block btn-48">
                                <?php echo e(__('Log in')); ?> <i class="d-none ml-3 fa fa-spinner fa-pulse"></i>
                            </button>

                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b6721487b7b8dd63e67398e09f7d70f121b9aa3)): ?>
<?php $component = $__componentOriginal7b6721487b7b8dd63e67398e09f7d70f121b9aa3; ?>
<?php unset($__componentOriginal7b6721487b7b8dd63e67398e09f7d70f121b9aa3); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/auth/login.blade.php ENDPATH**/ ?>