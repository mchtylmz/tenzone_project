<?php if (isset($component)) { $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SiteLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SiteLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> default.css <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Plans')); ?> <?php $__env->endSlot(); ?>

    <section class="tz-membership pt-5">
        <div class="container pt-3">
            <div class="text-center">
                <h2 class="head-title">Create your membership</h2>
                <ul class="tz-membernav nav nav-pills justify-content-center mb-5" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="id-monthly" data-bs-toggle="pill"
                                data-bs-target="#tab-monthly" type="button" role="tab" aria-controls="tab-monthly"
                                aria-selected="true">Monthly
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="id-annually" data-bs-toggle="pill" data-bs-target="#tab-annually"
                                type="button" role="tab" aria-controls="tab-annually" aria-selected="false">Annually
                        </button>
                    </li>
                </ul>
            </div>
            <div class="tab-content" id="pills-tabContent">
                <div class="tab-pane fade show active" id="tab-monthly" role="tabpanel">
                    <div class="owl-carousel owl-theme" id="tz-slider-membership">
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($plan->type == 'monthly'): ?>
                            <div class="item">
                                <div class="tz-pricing">
                                    <h3 class="name"><?php echo e($plan->name); ?></h3>
                                    <h4 class="price" style="color:#4060AA">£<?php echo e(number_format($plan->price, 0)); ?> <span>/month</span></h4>
                                    <span class="list-title">What You'll Get</span>
                                    <ul class="list-unstyled">
                                        <li>Activity Sheets</li>
                                        <li>Worksheets</li>
                                        <li>Weekly Feedback</li>
                                    </ul>
                                    <a href="<?php echo e(route('register', [$plan->slug, 1])); ?>" class="btn btn-outline-primary btn-block">
                                        Choose
                                    </a>
                                </div>
                            </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="tab-pane fade" id="tab-annually" role="tabpanel">
                    <div class="owl-carousel owl-theme" id="tz-slider-membership2">
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($plan->type == 'yearly'): ?>
                            <div class="item">
                                <div class="tz-pricing">
                                    <h3 class="name"><?php echo e($plan->name); ?></h3>
                                    <h4 class="price" style="color:#4060AA">
                                        £<?php echo e(number_format($plan->price, 0)); ?> <span>/yearly</span>
                                    </h4>
                                    <span class="list-title">What You'll Get</span>
                                    <ul class="list-unstyled">
                                        <li>Activity Sheets</li>
                                        <li>Worksheets</li>
                                        <li>Weekly Feedback</li>
                                    </ul>
                                    <a href="<?php echo e(route('register', [$plan->slug, 12])); ?>" class="btn btn-outline-primary btn-block">
                                        Choose
                                    </a>
                                </div>
                            </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <hr>

    <input id="card-holder-name" type="text">

    <!-- Stripe Elements Placeholder -->
    <div id="card-element"></div>

    <button id="card-button">
        Process Payment
    </button>

    <script src="https://js.stripe.com/v3/"></script>

    <script>
        const stripe = Stripe('pk_test_51L2AFUF1efQtdFH9YTY3WwOvUdntVm2xPFMVv9rT63olkMHm3fbgXxJZWkOQOFjQUiza1GvzEgXN9UZZNKXWIRlB00MqY17eYp');

        const elements = stripe.elements();
        const cardElement = elements.create('card');

        cardElement.mount('#card-element');
        const cardHolderName = document.getElementById('card-holder-name');
        const cardButton = document.getElementById('card-button');

        cardButton.addEventListener('click', async (e) => {
            const { paymentMethod, error } = await stripe.createPaymentMethod(
                'card', cardElement, {
                    billing_details: { name: cardHolderName.value }
                }
            );

            if (error) {
                // Display "error.message" to the user...
            } else {
                // The card has been verified successfully...
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311)): ?>
<?php $component = $__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311; ?>
<?php unset($__componentOriginal060ba1f57f99c8c33dc0afb221de7a92839c0311); ?>
<?php endif; ?>
<?php /**PATH /Users/mucahityilmaz/Desktop/Tenzone/resources/views/site/plans.blade.php ENDPATH**/ ?>