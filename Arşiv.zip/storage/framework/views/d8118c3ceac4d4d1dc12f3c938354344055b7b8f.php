<?php if (isset($component)) { $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PanelLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\PanelLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Dashboard Home')); ?> <?php $__env->endSlot(); ?>

    <div class="tm-page-head">
        <h1 class="title"><?php echo e($child->fullname); ?> Programme</h1>
        <p class="text mb-0">You can see your scheduled programs here.</p>
    </div>

    <div class="row">

        <div class="tm-calendar tm-calendar2">
            <div class="row g-0">

                <div class="col-lg-2">
                    <div class="nav-scroll">
                        <div class="nav flex-column nav-pills week_section" id="calendar" role="tablist" aria-orientation="vertical">
                            <?php $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button class="nav-link active" id="id-week<?php echo e($week->id); ?>" data-bs-toggle="pill" data-bs-target="#week<?php echo e($week->id); ?>" type="button" role="tab" aria-controls="week<?php echo e($week->id); ?>" aria-selected="true">
                                    <h4 class="title"><?php echo e($week->title); ?></h4>
                                    <span class="date">
                                        <?php echo e(date('d', strtotime($week->start_date))); ?> -
                                        <?php echo e(date('d M', strtotime($week->end_date))); ?>

                                    </span>
                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <div class="col-lg-10">
                    <div class="tab-content bg-white" id="calendarContent">
                        <?php $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane fade <?php echo e($loop->index == 0 ? 'show active':''); ?>"
                                 id="week<?php echo e($week->id); ?>" role="tabpanel">


                                <?php $__currentLoopData = $week->activities()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tm-calendar-item flex-between items-center">
                                        <div class="left flex-start items-center">
                                            <div class="text text-main">
                                                <?php echo e($activite->teacher()->first()->fullname); ?>

                                            </div>
                                            <div class="text"><?php echo e($activite->title); ?></div>
                                            <div class="text"><?php echo e($activite->type); ?></div>
                                        </div>
                                        <div class="right flex-end items-center">
                                            <?php if($activite->download): ?>
                                                <a target="_blank" href="<?php echo asset($activite->download); ?>"
                                                   class="btn">
                                                    <i class="ri-download-cloud-line"></i> Download
                                                </a>
                                            <?php endif; ?>
                                            <?php if($activite->watch): ?>
                                                <a target="_blank" href="<?php echo asset($activite->watch); ?>" class="btn">
                                                    <i class="ri-play-circle-line"></i> Watch
                                                </a>
                                            <?php endif; ?>
                                            <?php if($submission = $activite->submission()->first()): ?>
                                                <a target="_blank" href="<?php echo asset($submission->file); ?>" class="btn">
                                                    <i class="ri-download-cloud-line"></i>
                                                    View Submission
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937)): ?>
<?php $component = $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937; ?>
<?php unset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/panel/parent/programme.blade.php ENDPATH**/ ?>